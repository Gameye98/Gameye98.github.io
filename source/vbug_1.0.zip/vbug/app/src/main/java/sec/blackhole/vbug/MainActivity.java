package sec.blackhole.vbug;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.os.AsyncTask;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.ScrollView;
import android.text.Html;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.io.BufferedReader;
import org.apache.commons.codec.binary.Base64;
import java.nio.charset.StandardCharsets;
import com.google.android.gms.security.ProviderInstaller;
import javax.net.ssl.SSLContext;
import android.graphics.Typeface;
import org.json.JSONObject;
import java.io.FileOutputStream;
import java.io.File;
import java.io.BufferedInputStream;
import java.net.URL;
import android.graphics.drawable.ColorDrawable;
import android.graphics.Color;
import android.content.Intent;

public class MainActivity extends Activity 
{
	TextView xterm;
	EditText preter;
	ScrollView tscroll;
	int preterst = 0;
	int messagest = 0;
	VbugTask vbugTask;
	String endl = "\012";
	String vbugdir = Environment.getExternalStorageDirectory()+"/data/vbug";
	String list_of_virus = "<b><font color='yellow'>[</font><font color='red'>*</font><font color='yellow'>] </font><font color='white'>List of Virus</font></b><br/>";
	String normal_state = "<b><font color='red'>VIBUM</font><font color='yellow'>&nbsp;&gt;&nbsp;</font><font color='white'>choose&nbsp;</font></b>";
	String anvima_state = "<b><font color='red'>VIBUM&nbsp;</font><font color='yellow'>>&nbsp;</font><font color='white'>anvima</font><font color='yellow'>&nbsp;</b>";
	String winvima_state = "<b><font color='red'>VIBUM&nbsp;</font><font color='yellow'>>&nbsp;</font><font color='white'>winvima</font><font color='yellow'>&nbsp;</b>";
	String macvima_state = "<b><font color='red'>VIBUM&nbsp;</font><font color='yellow'>>&nbsp;</font><font color='white'>macvima</font><font color='yellow'>&nbsp;</b>";
	
	public class VbugTask extends AsyncTask<String, String, String>
	{
		@Override
		protected void onProgressUpdate(String[] values) {
			super.onProgressUpdate(values);
			printf(values[0], values[1]);
		}
		@Override
		protected String doInBackground(String[] params) {
			try {
				publishProgress("<b><br/>&nbsp;<font color='yellow'>[</font><font color='red'>+</font><font color='yellow'>]</font><font color='white'>&nbsp;Download&nbsp;the&nbsp;virus</font><font color='red'>...</font></b>","html");
				BufferedInputStream bis = new BufferedInputStream(new URL(params[0]).openStream());
				FileOutputStream out = new FileOutputStream(params[1]);
				byte[] data = new byte[1024];
				int byteContent;
				while((byteContent = bis.read(data, 0, 1024)) != -1) {
					out.write(data, 0, byteContent);
				}
				out.close();
				publishProgress("<b>&nbsp;<font color='white'>OK</font></b><br/>","html");
				publishProgress(String.format("<b>&nbsp;<font color='yellow'>[</font><font color='red'>+</font><font color='yellow'>]</font><font color='white'>&nbsp;Output:&nbsp;%s</font></b><br/>", params[1]),"html");
				publishProgress("<b>&nbsp;<font color='yellow'>[</font><font color='red'>+</font><font color='yellow'>]</font><font color='white'>&nbsp;Done</font><font color='red'>.</font></b><br/>","html");
				switch(preterst) {
					case 1: publishProgress(anvima_state,"html");
					break;
					case 2: publishProgress(winvima_state,"html");
					break;
					case 3: publishProgress(macvima_state,"html");
					break;
				}
			} catch(Exception e) {
				publishProgress(endl+e.toString()+endl,"text");
				switch(preterst) {
					case 1: publishProgress(anvima_state,"html");
					break;
					case 2: publishProgress(winvima_state,"html");
					break;
					case 3: publishProgress(macvima_state,"html");
					break;
				}
			}
			return null;
		}
	}
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		Intent intent = new Intent(this, MainActivity.class);
		startService(intent);
		try {
			ProviderInstaller.installIfNeeded(getApplicationContext());
			SSLContext sslContext;
			sslContext = SSLContext.getInstance("TLSv1.2");
			sslContext.init(null, null, null);
			sslContext.createSSLEngine();
		} catch(Exception e) {
			e.printStackTrace();
		}
		if(android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
			getWindow().setNavigationBarColor(Color.parseColor("#FFFFFF"));
		}
		getActionBar().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#FFFFFF")));
		xterm = findViewById(R.id.xterm);
		preter = findViewById(R.id.preter);
		tscroll = findViewById(R.id.tscroll);
		preter.setOnKeyListener(new OnKeyListener() {
			public boolean onKey(View v, int keyCode, KeyEvent event) {
				if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
					(keyCode == KeyEvent.KEYCODE_ENTER)) {
					CmdExec(preter.getText().toString());
					return false;
				}
				return true;
			}
		});
		Typeface tf = Typeface.createFromAsset(getAssets(), "ubuntu.ttf");
		xterm.setTypeface(tf);
		xterm.setTextSize(12);
		preter.setTypeface(tf);
		clear();banner();printf("\012","text");
		readAssets("message.txt","Cg==");
		printf("<b><font color='yellow'>[</font><font color='red'>~</font><font color='yellow'>]</font><font color='red'>&nbsp;Press&nbsp;Enter&nbsp;to&nbsp;Continue...</font></b><br/>","html");
		File ddir = new File(Environment.getExternalStorageDirectory()+"/data");
		if(ddir.exists()) {
			if(ddir.isFile()) {
				ddir.delete();
				ddir.mkdir();
			}
		} else {
			ddir.mkdir();
		}
		File vdir = new File(vbugdir);
		if(vdir.exists()) {
			if(vdir.isFile()) {
				vdir.delete();
				vdir.mkdir();
			}
		} else {
			vdir.mkdir();
		}
    }
	public void CmdExec(String commd) {
		preter.setText("");
		if(messagest == 0) {
			clear();banner();
			readAssets("info.txt","PGJyLz4K");
			readAssets("menu.txt","Cg==");
			printf("<b><font color='red'>VIBUM</font><font color='yellow'>&nbsp;&gt;&nbsp;</font><font color='white'>choose&nbsp;</font></b>","html");
			messagest = 1;
		} else {
			switch(preterst) {
				case 0:
					printf(commd+endl,"text");
					if(commd.equals("1") || commd.equals("01")) {
						readAssets("anvima.txt","Cg==");
						printf(list_of_virus,"html");
						try {
							InputStream is = getAssets().open("vbug.json");
							InputStreamReader isr = new InputStreamReader(is);
							BufferedReader br = new BufferedReader(isr);
							String content="";String inputLine;
							while((inputLine = br.readLine()) != null) {
								content += inputLine + endl;
							}
							JSONObject jsonObj = new JSONObject(content);
							for(int x = 0;x < jsonObj.getJSONArray("anvima").length();x++) {
								String num = String.valueOf(x+1);
								if(num.length() < 2) {
									num = "0" + num;
								}
								printf(String.format("<b>&nbsp;&nbsp;&nbsp;<font color='red'>(</font><font color='yellow'>%s</font><font color='red'>)</font><font color='white'>&nbsp;%s</font></b><br/>",num,jsonObj.getJSONArray("anvima").getJSONObject(x).getString("name")),"html");
							}
							printf("<br/><b>&nbsp;&nbsp;&nbsp;<font color='red'>(</font><font color='yellow'>00</font><font color='red'>)</font><font color='white'>&nbsp;Back to main menu</font></b><br/>","html");
							printf("\012","text");
							printf(anvima_state,"html");
						} catch(Exception e) {
							printf(e.toString()+endl,"text");
							printf(anvima_state,"html");
						}
						preterst = 1;
					} else if(commd.equals("2") || commd.equals("02")) {
						readAssets("winvima.txt","PGJyLz4K");
						printf(list_of_virus,"html");
						try {
							InputStream is = getAssets().open("vbug.json");
							InputStreamReader isr = new InputStreamReader(is);
							BufferedReader br = new BufferedReader(isr);
							String content="";String inputLine;
							while((inputLine = br.readLine()) != null) {
								content += inputLine + endl;
							}
							JSONObject jsonObj = new JSONObject(content);
							for(int x = 0;x < jsonObj.getJSONArray("winvima").length();x++) {
								String num = String.valueOf(x+1);
								if(num.length() < 2) {
									num = "0" + num;
								}
								printf(String.format("<b>&nbsp;&nbsp;&nbsp;<font color='red'>(</font><font color='yellow'>%s</font><font color='red'>)</font><font color='white'>&nbsp;%s</font></b><br/>",num,jsonObj.getJSONArray("winvima").getJSONObject(x).getString("name")),"html");
							}
							printf("<br/><b>&nbsp;&nbsp;&nbsp;<font color='red'>(</font><font color='yellow'>00</font><font color='red'>)</font><font color='white'>&nbsp;Back to main menu</font></b><br/>","html");
							printf("\012","text");
							printf(winvima_state,"html");
						} catch(Exception e) {
							printf(e.toString()+endl,"text");
							printf(winvima_state,"html");
						}
						preterst = 2;
					} else if(commd.equals("3") || commd.equals("03")) {
						readAssets("macvima.txt","PGJyLz4K");
						printf(list_of_virus,"html");
						try {
							InputStream is = getAssets().open("vbug.json");
							InputStreamReader isr = new InputStreamReader(is);
							BufferedReader br = new BufferedReader(isr);
							String content="";String inputLine;
							while((inputLine = br.readLine()) != null) {
								content += inputLine + endl;
							}
							JSONObject jsonObj = new JSONObject(content);
							for(int x = 0;x < jsonObj.getJSONArray("macvima").length();x++) {
								String num = String.valueOf(x+1);
								if(num.length() < 2) {
									num = "0" + num;
								}
								printf(String.format("<b>&nbsp;&nbsp;&nbsp;<font color='red'>(</font><font color='yellow'>%s</font><font color='red'>)</font><font color='white'>&nbsp;%s</font></b><br/>",num,jsonObj.getJSONArray("macvima").getJSONObject(x).getString("name")),"html");
							}
							printf("<br/><b>&nbsp;&nbsp;&nbsp;<font color='red'>(</font><font color='yellow'>00</font><font color='red'>)</font><font color='white'>&nbsp;Back to main menu</font></b><br/>","html");
							printf("\012","text");
							printf(macvima_state,"html");
						} catch(Exception e) {
							printf(e.toString()+endl,"text");
							printf(macvima_state,"html");
						}
						preterst = 3;
					} else if(commd.equals("4") || commd.equals("04")) {
						clear();banner();printf("\012","text");
						readAssets("message.txt","Cg==");
						printf("<b><font color='yellow'>[</font><font color='red'>~</font><font color='yellow'>]</font><font color='red'>&nbsp;Press&nbsp;Enter&nbsp;to&nbsp;Continue...</font></b><br/>","html");
						messagest = 0;preterst = 0;
					} else if(commd.equals("5") || commd.equals("05")) {
						finish();
					} else {
						printf("<b><font color='yellow'>[</font><font color='red'>!</font><font color='yellow'>]</font><font color='red'> ERROR</font><font color='yellow'>:</font><font color='white'> Wrong Input...</font></b><br/>","html");
						printf(normal_state,"html");
					}
				break;
				case 1:
					printf(commd+endl,"text");
					if(commd.equals("0") || commd.equals("00")) {
						preterst = 0;
						messagest = 0;
						CmdExec("0");
					} else {
						try {
							InputStream is = getAssets().open("vbug.json");
							InputStreamReader isr = new InputStreamReader(is);
							BufferedReader br = new BufferedReader(isr);
							String content="";String inputLine;
							while((inputLine = br.readLine()) != null) {
								content += inputLine + endl;
							}
							JSONObject jsonObj = new JSONObject(content);
							JSONObject notvir = jsonObj.getJSONArray("anvima").getJSONObject(Integer.valueOf(commd)-1);
							if(notvir.getString("type").equals("code")) {
								printf("<b><br/>&nbsp;<font color='yellow'>[</font><font color='red'>+</font><font color='yellow'>]</font><font color='white'>&nbsp;Download&nbsp;the&nbsp;virus</font><font color='red'>...</font>&nbsp;<font color='white'>OK</font></b><br/>","html");
								FileOutputStream out = new FileOutputStream(vbugdir+"/"+notvir.getString("output"));
								out.write(notvir.getString("content").getBytes());
								out.close();
								printf(String.format("<b>&nbsp;<font color='yellow'>[</font><font color='red'>+</font><font color='yellow'>]</font><font color='white'>&nbsp;Output: %s</font></b><br/>", vbugdir+"/"+notvir.getString("output")),"html");
								printf("<b>&nbsp;<font color='yellow'>[</font><font color='red'>+</font><font color='yellow'>]</font><font color='white'>&nbsp;Done</font><font color='red'>.</font></b><br/>","html");
								printf(anvima_state,"html");
							} else if(notvir.getString("type").equals("url")) {
								vbugTask = new VbugTask();
								vbugTask.execute(notvir.getString("content"),vbugdir+"/"+notvir.getString("output"));
							}
						} catch(Exception e) {
							printf("<b><font color='yellow'>[</font><font color='red'>!</font><font color='yellow'>]</font><font color='red'> ERROR</font><font color='yellow'>:</font><font color='white'> Wrong Input...</font></b><br/>","html");
							printf(anvima_state,"html");
						}
					}
				break;
				case 2:
					printf(commd+endl,"text");
					if(commd.equals("0") || commd.equals("00")) {
						preterst = 0;
						messagest = 0;
						CmdExec("0");
					} else {
						try {
							InputStream is = getAssets().open("vbug.json");
							InputStreamReader isr = new InputStreamReader(is);
							BufferedReader br = new BufferedReader(isr);
							String content="";String inputLine;
							while((inputLine = br.readLine()) != null) {
								content += inputLine + endl;
							}
							JSONObject jsonObj = new JSONObject(content);
							JSONObject notvir = jsonObj.getJSONArray("winvima").getJSONObject(Integer.valueOf(commd)-1);
							if(notvir.getString("type").equals("code")) {
								printf("<b><br/>&nbsp;<font color='yellow'>[</font><font color='red'>+</font><font color='yellow'>]</font><font color='white'>&nbsp;Download&nbsp;the&nbsp;virus</font><font color='red'>...</font>&nbsp;<font color='white'>OK</font></b><br/>","html");
								FileOutputStream out = new FileOutputStream(vbugdir+"/"+notvir.getString("output"));
								out.write(notvir.getString("content").getBytes());
								out.close();
								printf(String.format("<b>&nbsp;<font color='yellow'>[</font><font color='red'>+</font><font color='yellow'>]</font><font color='white'>&nbsp;Output: %s</font></b><br/>", vbugdir+"/"+notvir.getString("output")),"html");
								printf("<b>&nbsp;<font color='yellow'>[</font><font color='red'>+</font><font color='yellow'>]</font><font color='white'>&nbsp;Done</font><font color='red'>.</font></b><br/>","html");
								printf(winvima_state,"html");
							} else if(notvir.getString("type").equals("url")) {
								vbugTask = new VbugTask();
								vbugTask.execute(notvir.getString("content"),vbugdir+"/"+notvir.getString("output"));
							}
						} catch(Exception e) {
							printf("<b><font color='yellow'>[</font><font color='red'>!</font><font color='yellow'>]</font><font color='red'> ERROR</font><font color='yellow'>:</font><font color='white'> Wrong Input...</font></b><br/>","html");
							printf(winvima_state,"html");
						}
					}
				break;
				case 3:
					printf(commd+endl,"text");
					if(commd.equals("0") || commd.equals("00")) {
						preterst = 0;
						messagest = 0;
						CmdExec("0");
					} else {
						try {
							InputStream is = getAssets().open("vbug.json");
							InputStreamReader isr = new InputStreamReader(is);
							BufferedReader br = new BufferedReader(isr);
							String content="";String inputLine;
							while((inputLine = br.readLine()) != null) {
								content += inputLine + endl;
							}
							JSONObject jsonObj = new JSONObject(content);
							JSONObject notvir = jsonObj.getJSONArray("macvima").getJSONObject(Integer.valueOf(commd)-1);
							if(notvir.getString("type").equals("code")) {
								printf("<b><br/>&nbsp;<font color='yellow'>[</font><font color='red'>+</font><font color='yellow'>]</font><font color='white'>&nbsp;Download&nbsp;the&nbsp;virus</font><font color='red'>...</font>&nbsp;<font color='white'>OK</font></b><br/>","html");
								FileOutputStream out = new FileOutputStream(vbugdir+"/"+notvir.getString("output"));
								out.write(notvir.getString("content").getBytes());
								out.close();
								printf(String.format("<b>&nbsp;<font color='yellow'>[</font><font color='red'>+</font><font color='yellow'>]</font><font color='white'>&nbsp;Output: %s</font></b><br/>", vbugdir+"/"+notvir.getString("output")),"html");
								printf("<b>&nbsp;<font color='yellow'>[</font><font color='red'>+</font><font color='yellow'>]</font><font color='white'>&nbsp;Done</font><font color='red'>.</font></b><br/>","html");
								printf(macvima_state,"html");
							} else if(notvir.getString("type").equals("url")) {
								vbugTask = new VbugTask();
								vbugTask.execute(notvir.getString("content"),vbugdir+"/"+notvir.getString("output"));
							}
						} catch(Exception e) {
							printf("<b><font color='yellow'>[</font><font color='red'>!</font><font color='yellow'>]</font><font color='red'> ERROR</font><font color='yellow'>:</font><font color='white'> Wrong Input...</font></b><br/>","html");
							printf(macvima_state,"html");
						}
					}
				break;
			}
		}
	}
	public void banner() {
		try {
			InputStream is = getAssets().open("banner.txt");
			InputStreamReader isr = new InputStreamReader(is);
			BufferedReader br = new BufferedReader(isr);
			String content="";String inputLine;
			while((inputLine = br.readLine()) != null) {
				content += inputLine + endl;
			}
			printf(new String(Base64.decodeBase64((content+"Cg==").getBytes(StandardCharsets.UTF_8))),"html");
		} catch(Exception e) {
			printf(e.toString()+endl,"txt");
		}
	}
	public void readAssets(String fileName, String keyString) {
		try {
			InputStream is = getAssets().open(fileName);
			InputStreamReader isr = new InputStreamReader(is);
			BufferedReader br = new BufferedReader(isr);
			String content="";String inputLine;
			while((inputLine = br.readLine()) != null) {
				content += inputLine + endl;
			}
			content = content.trim();
			printf(new String(Base64.decodeBase64((content+keyString).getBytes(StandardCharsets.UTF_8))),"html");
		} catch(Exception e) {
			printf(e.toString()+endl,"txt");
		}
	}
	public void clear() {
		xterm.setText("");
	}
	public void printf(String text, String format) {
		if(format.equals("text")) {
			xterm.append(text);
		} else if(format.equals("html")) {
			xterm.append(Html.fromHtml(text));
		}
		scroll();
	}
	public void scroll() {
		tscroll.post(new Runnable() {
			@Override
			public void run() {
				tscroll.fullScroll(tscroll.FOCUS_DOWN);
			}
		});
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.menu, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch(item.getItemId()) {
			case R.id.about: 
				AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
				builder.setTitle("vbug");
				builder.setMessage("(ID) Tool ini berfungsi untuk membuat virus secara instan. Dengan begitu pengguna vbug maker dapat menggunakannya dengan mudah dan cepat. Di dalam software tersebut telah disediakan 3 fitur yang bisa kita pilih, Anvima (Virus Untuk Android), Winvima (Virus untuk Windows) & MACvima (Virus untuk MACOSX)\n\n(EN) This tool works to create viruses instantly. That way vbug maker users can use it easily and quickly. Inside the software has provided 3 features that we can choose, Anvima (Virus For Android), Winvima (Virus for Window) & MACvima (Virus for MACOSX)\n\n\nCopyright (C) 2020 by DedSecTL\n\nDedSecTL\nCvar1984\nCiKu370\nLexiie\nMr.TenSwapper07\namsitlab\n[M]izuno\n3RROR_TMX\nMr.K3N\nZetSec\nTroublemaker97\nL_Viole\nX14N23N6\nMR.R45K1N\nlord.zephyrus\n4cliba788\nmr0x100\nViruz\nMr_007\nMicroClone\nIdannovita.\nBlackHole Security.");
				builder.setPositiveButton("OK", null);
				AlertDialog dialog = builder.show();
				dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.parseColor("#FFFFFF"));
				dialog.getButton(AlertDialog.BUTTON_POSITIVE).setBackgroundDrawable(new ColorDrawable(Color.parseColor("#000000")));
				dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#FFFFFF")));
				break;
		}
		return true;
	}
}
