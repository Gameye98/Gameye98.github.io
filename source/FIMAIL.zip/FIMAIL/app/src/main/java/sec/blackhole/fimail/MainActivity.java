package sec.blackhole.fimail;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.widget.*;
import android.view.*;
import android.view.View.*;
import java.io.*;
import java.util.*;
import android.content.*;
import java.util.regex.*;
import android.view.inputmethod.*;
import android.widget.TextView.*;

public class MainActivity extends Activity 
{
	private SendTask mTask;
	public String onFilterEmail(String email) {
		if(Pattern.compile("@gmail.co.uk").matcher(email).find()) {
			return "Gmail[UK]";
		} else if(Pattern.compile("@gmail.ca").matcher(email).find()) {
			return "Gmail[CA]";
		} else if(Pattern.compile("@gmail.de").matcher(email).find()) {
			return "Gmail[DE]";
		} else if(Pattern.compile("@gmail.ru").matcher(email).find()) {
			return "Gmail[RU]";
		} else if(Pattern.compile("@gmal.fr").matcher(email).find()) {
			return "Gmail[FR]";
		} else if(Pattern.compile("@gmail.com").matcher(email).find()) {
			return "Gmail[COM]";
		} else if(Pattern.compile("@gmail.co.id").matcher(email).find()) {
			return "Gmail[ID]";
		} else if(Pattern.compile("@gmail.com.au").matcher(email).find()) {
			return "Gmail[AU]";
		} else if(Pattern.compile("@gmail").matcher(email).find()) {
			return "Gmail[RANDOM]";
		} else if(Pattern.compile("@yahoo.ru").matcher(email).find()) {
			return "Yahoo[RU]";
		} else if(Pattern.compile("@yahoo.co.uk").matcher(email).find()) {
			return "Yahoo[UK]";
		} else if(Pattern.compile("@yahoo.de").matcher(email).find()) {
			return "Yahoo[DE]";
		} else if(Pattern.compile("@yahoo.com").matcher(email).find()) {
			return "Yahoo[COM]";
		} else if(Pattern.compile("@yahoo.fr").matcher(email).find()) {
			return "Yahoo[FR]";
		} else if(Pattern.compile("@yahoo.co.jp").matcher(email).find()) {
			return "Yahoo[JP]";
		} else if(Pattern.compile("@yahoo.com.br").matcher(email).find()) {
			return "Yahoo[BR]";
		} else if(Pattern.compile("@yahoo.co.in").matcher(email).find()) {
			return "Yahoo[CO.IN]";
		} else if(Pattern.compile("@yahoo.es").matcher(email).find()) {
			return "Yahoo[ES]";
		} else if(Pattern.compile("@yahoo.it").matcher(email).find()) {
			return "Yahoo[IT]";
		} else if(Pattern.compile("@yahoo.in").matcher(email).find()) {
			return "Yahoo[IN]";
		} else if(Pattern.compile("@yahoo.ca").matcher(email).find()) {
			return "Yahoo[CA]";
		} else if(Pattern.compile("@yahoo.com.au").matcher(email).find()) {
			return "Yahoo[AU]";
		} else if(Pattern.compile("@yahoo.com.ar").matcher(email).find()) {
			return "Yahoo[AR]";
		} else if(Pattern.compile("@yahoo.com.mx").matcher(email).find()) {
			return "Yahoo[MX]";
		} else if(Pattern.compile("@yahoo.co.id").matcher(email).find()) {
			return "Yahoo[ID]";
		} else if(Pattern.compile("@yahoo.com.sg").matcher(email).find()) {
			return "Yahoo[SG]";
		} else if(Pattern.compile("@yahoo").matcher(email).find()) {
			return "Yahoo[RANDOM]";
		} else if(Pattern.compile("@rocketmail").matcher(email).find()) {
			return "Rocketmail";
		} else if(Pattern.compile("@ymail").matcher(email).find()) {
			return "Ymail";
		} else if(Pattern.compile("@yandex.de").matcher(email).find()) {
			return "Yandex[DE]";
		} else if(Pattern.compile("@yandex.com.au").matcher(email).find()) {
			return "Yandex[AU]";
		} else if(Pattern.compile("@yandex.com").matcher(email).find()) {
			return "Yandex[COM]";
		} else if(Pattern.compile("@yandex.co.id").matcher(email).find()) {
			return "Yandex[ID]";
		} else if(Pattern.compile("@yandex.ru").matcher(email).find()) {
			return "Yandex[RU]";
		} else if(Pattern.compile("@yandex.co.uk").matcher(email).find()) {
			return "Yandex[UK]";
		} else if(Pattern.compile("@yandex.ca").matcher(email).find()) {
			return "Yandex[CA]";
		} else if(Pattern.compile("@yandex").matcher(email).find()) {
			return "Yandex[RANDOM]";
		} else if(Pattern.compile("@hotmail.com").matcher(email).find()) {
			return "Hotmail[COM]";
		} else if(Pattern.compile("@hotmail.co.id").matcher(email).find()) {
			return "Hotmail[ID]";
		} else if(Pattern.compile("@hotmail.co.uk").matcher(email).find()) {
			return "Hotmail[UK]";
		} else if(Pattern.compile("@hotmail.fr").matcher(email).find()) {
			return "Hotmail[FR]";
		} else if(Pattern.compile("@hotmail.ru").matcher(email).find()) {
			return "Hotmail[RU]";
		} else if(Pattern.compile("@hotmail.de").matcher(email).find()) {
			return "Hotmail[DE]";
		} else if(Pattern.compile("@hotmail.it").matcher(email).find()) {
			return "Hotmail[IT]";
		} else if(Pattern.compile("@hotmail.es").matcher(email).find()) {
			return "Hotmail[ES]";
		} else if(Pattern.compile("@hotmail").matcher(email).find()) {
			return "Hotmail[RANDOM]";
		} else if(Pattern.compile("@live.com").matcher(email).find()) {
			return "Live[COM]";
		} else if(Pattern.compile("@live.co.id").matcher(email).find()) {
			return "Live[ID]";
		} else if(Pattern.compile("@live.de").matcher(email).find()) {
			return "Live[DE]";
		} else if(Pattern.compile("@live.co.uk").matcher(email).find()) {
			return "Live[UK]";
		} else if(Pattern.compile("@live.fr").matcher(email).find()) {
			return "Live[FR]";
		} else if(Pattern.compile("@live.nl").matcher(email).find()) {
			return "Live[NL]";
		} else if(Pattern.compile("@live.com.au").matcher(email).find()) {
			return "Live[AU]";
		} else if(Pattern.compile("@live.ca").matcher(email).find()) {
			return "Live[CA]";
		} else if(Pattern.compile("@live.it").matcher(email).find()) {
			return "Live[IT]";
		} else if(Pattern.compile("@live").matcher(email).find()) {
			return "Live[RANDOM]";
		} else if(Pattern.compile("@outlook").matcher(email).find()) {
			return "Outlook";
		} else if(Pattern.compile("@icloud").matcher(email).find()) {
			return "iCloud";
		} else if(Pattern.compile("@rambler").matcher(email).find()) {
			return "Rambler";
		} else if(Pattern.compile("@mail").matcher(email).find()) {
			return "Mail";
		} else if(Pattern.compile("@aol").matcher(email).find()) {
			return "Aol";
		} else if(Pattern.compile("@sky").matcher(email).find()) {
			return "Sky";
		} else {
			return "Random";
		}
	}
	public class SendTask extends AsyncTask<String, Void, String>
	{
		private ProgressDialog pdia;

		@Override
		protected void onPreExecute()
		{
			super.onPreExecute();
			pdia = new ProgressDialog(MainActivity.this);
			pdia.setTitle("Filtering email...");
			pdia.setButton(DialogInterface.BUTTON_NEGATIVE, "Stop Process", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dlg, int which) {
					mTask.cancel(true);
					pdia.dismiss();
				}
			});
			pdia.setCancelable(false);
			pdia.show();
		}
		@Override
		protected String doInBackground(String[] params)
		{
			String[] list = params[0].split("\n");
			for(int x = 0;x < list.length;x++) {
				pdia.setMessage(x+"-"+list.length);
				if(mTask.isCancelled()) {
					break;
				}
				String mail = list[x]+"\n";
				String email = onFilterEmail(list[x]);
				try {
					FileOutputStream out = new FileOutputStream("/sdcard/FIMAIL/"+email+".txt",true);
					out.write(mail.getBytes());
					out.close();
				} catch(Exception e) {
					//nothing to do
				}
			}
			return null;
		}
		@Override
		protected void onPostExecute(String result)
		{
			pdia.dismiss();
			new AlertDialog.Builder(MainActivity.this)
			.setMessage("Success!!!")
			.setPositiveButton("OK",null)
			.show();
		}
	}
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		EditText maillist = (EditText) findViewById(R.id.maillist);
		TextView banner = (TextView) findViewById(R.id.banner);
		TextView country = (TextView) findViewById(R.id.country);
		TextView noncountry = (TextView) findViewById(R.id.noncountry);
		Button fimail = (Button) findViewById(R.id.fimail);
		Typeface tf = Typeface.createFromAsset(getAssets(), "FSEX300.ttf");
		maillist.setTypeface(tf);
		banner.setTypeface(tf);
		country.setTypeface(tf);
		noncountry.setTypeface(tf);
		fimail.setTypeface(tf);
		findViewById(R.id.fimail).setOnClickListener(filterMail);
    }
	View.OnClickListener filterMail = new View.OnClickListener() {
		public void onClick(View view) {
			EditText maillist = (EditText) findViewById(R.id.maillist);
			File fimail = new File("/sdcard/FIMAIL");
			if(fimail.exists() == true) {
				if(fimail.isFile() == true) {
					fimail.delete();
					fimail.mkdir();
				}
			} else {
				fimail.mkdir();
			}
			File file = new File(maillist.getText().toString());
			if(file.exists() == true) {
				if(file.isFile() == true) {
					maillist.onEditorAction(EditorInfo.IME_ACTION_DONE);
					maillist.setText("");
					try {
						Scanner sc = new Scanner(file, "UTF-8");
						sc.useDelimiter("$^");
						mTask = new SendTask();
						mTask.execute(sc.next());
					} catch(Exception e) {
						// nothing to do
					}
				} else {
					new AlertDialog.Builder(MainActivity.this)
					.setMessage("File not found!!!")
					.setPositiveButton(android.R.string.ok,null)
					.show();
				}
			} else {
				new AlertDialog.Builder(MainActivity.this)
				.setMessage("File not found!!!")
				.setPositiveButton(android.R.string.ok,null)
				.show();
			}
		}
	};
	@Override
	public void onBackPressed()
	{
		new AlertDialog.Builder(MainActivity.this)
		.setTitle("FIMAIL")
			.setMessage("An email filter is a type of program that filters and separates email into different files based on specified criteria.\n\nThe result will be saved in:\n/sdcard/FIMAIL\n\nCopyright (C) 2019 by DedSecTL\n\nDedSecTL\nCvar1984\nCiKu370\nMr.TenSwapper07\namsitlab\n[M]izuno\n3RROR_TMX\nMr.K3N\nZetSec\nTroublemaker97\nL_Viole\nX14N23N6\nMR.R45K1N\nlord.zephyrus\n4cliba788\nmr0x100\nMrx04\nViruz\nMr_007\nITermSec\nIdannovita.\nBlackHole Security.")
		.setPositiveButton("Contact",new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialogInterface, int whichButton) {
				new AlertDialog.Builder(MainActivity.this)
					.setMessage("Instagram: @dtlily\nTelegram: @dtlily\nFacebook: cgi.izo\nGitHub: Gameye98\nGitLab: dtlily\nYoutube: dtlily")
				.setPositiveButton("OK",null)
				.show();
			}
		})
		.setNegativeButton("Exit",new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialogInterface, int whichButton) {
				finish();
			}
		})
		.setNeutralButton("Cancel",null)
		.show();
	}
	
}
